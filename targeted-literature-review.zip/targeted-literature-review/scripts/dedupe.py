#!/usr/bin/env python3
"""Mark duplicate records in records.csv.

Matches, in order: PMID, then DOI, then normalised title + year.
The first record of each group is kept; later ones get dedupe_status = "duplicate of <id>".
Nothing is deleted, so the PRISMA counts can show what was removed.

Usage:  python scripts/dedupe.py records.csv
Required columns: id, pmid, doi, title, year  (others are kept as they are)
"""
import csv
import re
import sys
import unicodedata


def norm_doi(d):
    d = (d or "").strip().lower()
    d = re.sub(r"^https?://(dx\.)?doi\.org/", "", d)
    return d.removeprefix("doi:").strip()


def norm_title(t):
    t = unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode()
    t = re.sub(r"[^a-z0-9 ]", " ", t.lower())
    return re.sub(r"\s+", " ", t).strip()


def main(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        fields = list(reader.fieldnames or [])
    missing = {"id", "pmid", "doi", "title", "year"} - set(fields)
    if missing:
        sys.exit(f"records.csv is missing columns: {', '.join(sorted(missing))}")
    if "dedupe_status" not in fields:
        fields.append("dedupe_status")

    seen = {}
    dupes = 0
    for r in rows:
        keys = []
        if (r.get("pmid") or "").strip():
            keys.append(("pmid", r["pmid"].strip()))
        if norm_doi(r.get("doi")):
            keys.append(("doi", norm_doi(r["doi"])))
        if norm_title(r.get("title")):
            keys.append(("title", norm_title(r["title"]) + "|" + (r.get("year") or "").strip()))
        first = next((seen[k] for k in keys if k in seen), None)
        if first:
            r["dedupe_status"] = f"duplicate of {first}"
            dupes += 1
        else:
            r["dedupe_status"] = "unique"
            for k in keys:
                seen[k] = r["id"]

    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} records, {dupes} duplicates marked, {len(rows) - dupes} unique")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
