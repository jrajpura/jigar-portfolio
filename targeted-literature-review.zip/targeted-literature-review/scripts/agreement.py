#!/usr/bin/env python3
"""Agreement between Claude and a human reviewer on the calibration pilot.

Reports percent agreement and Cohen's kappa across INCLUDE / EXCLUDE / UNCERTAIN,
plus the disagreements so the criteria wording can be clarified.

Usage:  python scripts/agreement.py pilot.csv [claude_column] [human_column]
Defaults: claude_column = ta_decision, human_column = human_ta_decision.
Rows where either decision is blank are skipped and counted.
"""
import csv
import sys
from collections import Counter

LABELS = ("INCLUDE", "EXCLUDE", "UNCERTAIN")


def main(path, a_col="ta_decision", b_col="human_ta_decision"):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    pairs, skipped, disagree = [], 0, []
    for r in rows:
        a = (r.get(a_col) or "").strip().upper()
        b = (r.get(b_col) or "").strip().upper()
        if not a or not b:
            skipped += 1
            continue
        for x in (a, b):
            if x not in LABELS:
                sys.exit(f"Unknown decision '{x}' (row id {r.get('id', '?')}); use {', '.join(LABELS)}")
        pairs.append((a, b))
        if a != b:
            disagree.append((r.get("id", "?"), a, b, (r.get("title") or "")[:80]))

    n = len(pairs)
    if n == 0:
        sys.exit("No rows with both decisions filled in.")
    po = sum(a == b for a, b in pairs) / n
    ca, cb = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    pe = sum(ca[l] * cb[l] for l in LABELS) / (n * n)
    kappa = 1.0 if pe == 1 else (po - pe) / (1 - pe)

    print(f"Records compared: {n} (skipped {skipped} with a blank decision)")
    print(f"Percent agreement: {po:.1%}")
    print(f"Cohen's kappa: {kappa:.2f}")
    if n < 30:
        print("Note: fewer than 30 records; kappa is unstable at this size.")
    print("\nConfusion table (rows = Claude, columns = human):")
    print("            " + "".join(f"{l:>11}" for l in LABELS))
    for la in LABELS:
        print(f"{la:>11} " + "".join(f"{sum(1 for a, b in pairs if a == la and b == lb):>11}" for lb in LABELS))
    if disagree:
        print(f"\nDisagreements ({len(disagree)}):")
        for d in disagree:
            print(f"  id {d[0]}: Claude {d[1]}, human {d[2]}  {d[3]}")


if __name__ == "__main__":
    if len(sys.argv) not in (2, 4):
        sys.exit(__doc__)
    main(*sys.argv[1:])
