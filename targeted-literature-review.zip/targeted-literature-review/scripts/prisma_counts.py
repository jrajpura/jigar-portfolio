#!/usr/bin/env python3
"""PRISMA-style flow counts, computed from records.csv so the report always reconciles.

Uses the final (human-confirmed) decision where present, otherwise Claude's decision:
  title/abstract: human_ta_decision, else ta_decision
  full text:      human_ft_decision, else ft_decision
Full-text exclusion reasons come from ft_reason.
Records still UNCERTAIN or blank at either stage are reported as unresolved, so gaps show up.

Usage:  python scripts/prisma_counts.py records.csv
Required columns: id, source, dedupe_status, ta_decision, ft_decision
Optional: human_ta_decision, human_ft_decision, ft_reason
"""
import csv
import sys
from collections import Counter


def final(r, human, ai):
    return ((r.get(human) or "").strip() or (r.get(ai) or "").strip()).upper()


def main(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        sys.exit("records.csv has no rows.")
    missing = {"id", "source", "dedupe_status", "ta_decision", "ft_decision"} - set(rows[0])
    if missing:
        sys.exit(f"records.csv is missing columns: {', '.join(sorted(missing))}")

    by_source = Counter((r.get("source") or "unspecified").strip() for r in rows)
    unique = [r for r in rows if (r.get("dedupe_status") or "").strip().lower() in ("unique", "")]
    dup = len(rows) - len(unique)

    ta = Counter(final(r, "human_ta_decision", "ta_decision") or "BLANK" for r in unique)
    to_ft = [r for r in unique if final(r, "human_ta_decision", "ta_decision") == "INCLUDE"]
    ft = Counter(final(r, "human_ft_decision", "ft_decision") or "BLANK" for r in to_ft)
    reasons = Counter((r.get("ft_reason") or "reason not recorded").strip()
                      for r in to_ft if final(r, "human_ft_decision", "ft_decision") == "EXCLUDE")

    print("IDENTIFICATION")
    for s, n in sorted(by_source.items()):
        print(f"  Records from {s}: {n}")
    print(f"  Total records identified: {len(rows)}")
    print(f"  Duplicates removed: {dup}")
    print("SCREENING (titles and abstracts)")
    print(f"  Records screened: {len(unique)}")
    print(f"  Records excluded: {ta['EXCLUDE']}")
    print(f"  Unresolved (UNCERTAIN or blank): {ta['UNCERTAIN'] + ta['BLANK']}")
    print("ELIGIBILITY (full text)")
    print(f"  Reports assessed: {len(to_ft)}")
    print(f"  Reports excluded: {ft['EXCLUDE']}")
    for reason, n in reasons.most_common():
        print(f"    {reason}: {n}")
    print(f"  Unresolved (UNCERTAIN or blank): {ft['UNCERTAIN'] + ft['BLANK']}")
    print("INCLUDED")
    print(f"  Studies included: {ft['INCLUDE']}")

    open_items = ta["UNCERTAIN"] + ta["BLANK"] + ft["UNCERTAIN"] + ft["BLANK"]
    if open_items:
        print(f"\nWARNING: {open_items} records are unresolved. Resolve them before reporting the flow.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
