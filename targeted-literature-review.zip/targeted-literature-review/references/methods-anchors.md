# Methods anchors for targeted literature reviews

There is no formal methods standard for a targeted literature review (TLR). This skill anchors its shortcuts to the Cochrane Rapid Reviews Methods Group guidance and states each one in the protocol.

Sources (read the originals before changing anything here):
- Garritty C et al. Updated recommendations for the Cochrane rapid review methods guidance for rapid reviews of effectiveness. BMJ 2024;384:e076335. https://doi.org/10.1136/bmj-2023-076335
- Cochrane Rapid Reviews Methods Group. Interim guidance, March 2020. https://methods.cochrane.org/rapidreviews/cochrane-rr-methods

## Shortcuts this skill adopts

| Step | Full SLR standard | What this skill does instead | Why this is acceptable for a TLR |
| --- | --- | --- | --- |
| Appropriateness | n/a | Confirm a TLR fits the decision before starting; warn when an SLR is needed (HTA clinical evidence, EU JCA PICOs) | Cochrane asks reviewers to judge first whether an abbreviated review is appropriate |
| Databases | Several databases plus grey literature | PubMed via connector; other databases only as user-supplied exports | Restricted searching is a recognised rapid review shortcut; it must be reported |
| Search validation | Peer-reviewed strategy | Seed set of 3–5 known papers must be retrieved | Gives a simple, reportable check of recall |
| Calibration | Pilot on a sample | Pilot on 30–50 records, agreement reported | Matches the Cochrane interim recommendation |
| Title/abstract screening | Two independent reviewers | Claude screens; a human checks every exclusion (or a pre-specified sample, stated in the report) | Mirrors one screener plus a second reviewer checking exclusions |
| Full-text screening | Two independent reviewers | Claude assesses; human confirms every inclusion and exclusion | Exclusions at full text are high-stakes |
| Data extraction | Two independent extractors | Claude extracts with a source location for every value; human verifies every numeric field | Mirrors single extraction with verification |
| Quality appraisal | Formal, dual | Optional; if used, Claude drafts and a human confirms every judgement | Often omitted in TLRs; when used, verification is required |

## Benchmark to beat

Cochrane methods work found that a single human screener misses about 13% of relevant studies on average, against about 3% with dual screening. The skill's screening recall should be at least as good as a single human screener. Measure it on your own benchmark (see SKILL.md, Step 8 in the guide).

## What must always be reported

- Every shortcut above that was used, and any that were not.
- Databases, search dates and full search strings.
- How exclusions were checked (all, or a stated sample).
- Which steps used AI and what the human checked (see elevate-genai-items.md).

## Edit me

This file is your house standard. Change the shortcuts to match how your team works, and keep the "why" column honest.
