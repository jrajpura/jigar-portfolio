# AI-use reporting checklist

My own working checklist for reporting AI use in a review, written to align with:
- ELEVATE-GenAI reporting guideline, ISPOR Working Group on Generative AI. Value in Health 2025. doi:10.1016/j.jval.2025.06.018. EQUATOR entry: https://www.equator-network.org/reporting-guidelines/elevate-genai/
- Cochrane, Campbell, JBI and CEE position statement on AI in evidence synthesis, 2025. https://pmc.ncbi.nlm.nih.gov/articles/PMC12594113/

This is not the official checklist. Before reporting a review externally, complete the published ELEVATE-GenAI checklist and use this file only as a prompt for what to collect along the way.

## Collect during the review

1. **Model and access.** Model name and version, interface (chat, API, app), dates of use.
2. **Tasks.** Each review task where AI was used, and its role: drafted for human decision, or decided with human verification.
3. **Inputs.** Frozen eligibility criteria, prompts or instructions used for screening and extraction, and their version dates.
4. **Human oversight.** For each AI-assisted task, what the human checked (all records, a stated sample) and who the accountable reviewer is.
5. **Accuracy.** Search recall against the seed set; pilot agreement (percent and Cohen's kappa); number of AI exclusions overturned by the human check; extraction error rate found at verification.
6. **Completeness.** Records with no abstract or no full text, and how they were handled.
7. **Uncertainty.** How doubtful records were flagged (UNCERTAIN) and resolved.
8. **Reproducibility.** Whether the same criteria and model version would be used to repeat the review; files kept (records.csv, extraction.csv, ai_use_log.md).
9. **Limitations.** Known weaknesses of the AI-assisted steps and of the TLR shortcuts.
10. **Accountability statement.** The named reviewer remains responsible for the review, including the decision to use AI.

## Report as

A short methods appendix headed "Use of generative AI", followed by the completed published checklist when the review is shared outside the team.
