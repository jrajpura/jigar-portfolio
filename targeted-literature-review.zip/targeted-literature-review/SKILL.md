---
name: targeted-literature-review
description: Runs a targeted literature review for HEOR/RWE: protocol, PubMed search, screening and extraction with human checkpoints, synthesis and an AI-use log. Not for HTA SLRs.
---

# Targeted literature review (TLR)

Use for targeted, focused, pragmatic or landscape reviews: burden of illness, epidemiology, treatment patterns, unmet need, HRQoL and utilities, costs and resource use, PRO instrument landscapes, surrogate-outcome links, evidence gap analysis, or scoping whether a full SLR is needed.

## Ground rules
1. A TLR is not an SLR. If the review will be the clinical evidence base of an HTA submission (NICE, G-BA, HAS, EU JCA), say so: those need systematic retrieval. Offer a scoping TLR, or the same workflow scaled up to SLR methods.
2. Never cite from memory. Every study, number and citation must trace to a record retrieved in this session (PMID or DOI) and, for numbers, to a page, table or the abstract.
3. Never use the model as a search engine. Write Boolean strings and run them in a real database (the PubMed connector). Ask for exports from other databases.
4. Humans decide; Claude drafts and flags. Stop at every checkpoint. If running unattended, take the most reasonable choice, log it, and flag it at the top of the report.
5. Flag, don't drop. Uncertain records go forward as UNCERTAIN, never EXCLUDE.
6. Log every AI step as you go (see Step 8).

## Methods anchors
Read references/methods-anchors.md before Step 1. State in the protocol which Cochrane rapid review shortcuts are used and why.

## Workflow
Keep three working files: records.csv, extraction.csv, ai_use_log.md.

records.csv columns: id, source, pmid, doi, title, year, journal, abstract, dedupe_status, ta_decision, ta_criterion, ta_reason, human_ta_decision, ft_decision, ft_reason, human_ft_decision.
Decisions are always INCLUDE, EXCLUDE or UNCERTAIN. Claude fills the ta_ and ft_ columns; the human fills the human_ columns.

### 1. Protocol
Ask only what is missing (one round): decision and audience; population, geography, period, languages; outcomes; study designs; other sources the user can supply; time budget.
Draft: objective, review questions, PECOS eligibility table (include and exclude), sources and limits, planned shortcuts with reasons, which steps are AI-assisted and what the human checks, synthesis approach.
CHECKPOINT 1: user approves. Freeze criteria; log version and date.

### 2. Search
Ask for 3 to 5 seed papers. Draft the PubMed string in blocks (condition AND concept AND design), MeSH plus free text, explicit limits. Run it; every seed must be retrieved, or explain why not. Optionally add related-article (pearl growing) results as a separate source. Merge user exports; run `python scripts/dedupe.py records.csv`. Write all records to records.csv.
CHECKPOINT 2: user approves the final string. Log string, database, date and hit count.

### 3. Calibration pilot
Screen 30 to 50 random records: INCLUDE / EXCLUDE / UNCERTAIN, deciding criterion, one-line reason.
CHECKPOINT 3: user marks disagreements. Clarify wording, not scope. Run `python scripts/agreement.py pilot.csv` and log percent agreement and kappa.

### 4. Title and abstract screening
Screen the rest with the frozen criteria. No abstract means UNCERTAIN. Re-screen a random 10% of own exclusions in a fresh pass; report flips.
CHECKPOINT 4: user checks every exclusion, or a pre-specified sample plus all UNCERTAIN. Log which.

### 5. Full text
Retrieve open-access full text with the connector or ask for PDFs. Record an exclusion reason for each exclusion. Abstract-only assessments are flagged.
CHECKPOINT 5: user confirms the included set.

### 6. Extraction
Start extraction.csv from references/extraction-template.csv and agree any extra columns with the user first. Record the location of every value. Copy numbers exactly; label any calculation; NR when not reported. Re-open the source to confirm every numeric field.
CHECKPOINT 6: human verifies all numeric fields; log the error rate found.

### 7. Synthesis and report
Synthesise only from verified extraction: lead finding per question, evidence tables, narrative by outcome then setting, gaps, limitations of the evidence and of the TLR method. Build the adapted PRISMA flow with `python scripts/prisma_counts.py records.csv`; do not report the flow while it warns of unresolved records.
Deliver a document (report) and a spreadsheet (records and extraction).

### 8. AI-use log
Append ai_use_log.md as a methods appendix: model and version, dates, each AI-assisted task and its human check, frozen criteria and prompts, validation results (seed recall, pilot agreement, exclusion flips, extraction error rate), limitations, named accountable reviewer. Cross-check against references/elevate-genai-items.md and note gaps.

## Output rules
Cite every study with PMID and DOI. Keep evidence separate from interpretation. Quote sources rarely and briefly. If any checkpoint was skipped, say so at the top.
