# targeted-literature-review · version 1.0 (October 2026)

A skill that runs a targeted literature review (TLR) for HEOR and RWE questions with Claude: protocol, PubMed search, screening and extraction with a human checkpoint at every stage, synthesis, and an AI-use log.

Built and explained step by step in Project 06 of jigarrajpura.com (Build a targeted literature review skill in Claude).

## Install in Claude
1. In Claude, open Customize › Skills.
2. Click +, then + Create skill, then Upload a skill.
3. Upload this ZIP as downloaded (do not unzip and re-zip it).
4. Skills need code execution switched on. Connect PubMed through Claude's connectors so the skill can search a real database.
5. Test it: "Use my targeted-literature-review skill: [your question]". Claude should start with a protocol and stop for your approval.

## What's inside
- SKILL.md: the workflow Claude follows
- references/: methods anchors, extraction template, AI-use reporting checklist (edit these to match your team's standard)
- scripts/: deduplication, pilot agreement (percent and Cohen's kappa), PRISMA flow counts

Read every file, especially the scripts, before switching the skill on.

## Disclaimer
Personal project by Jigar Rajpura. Not sponsored by or affiliated with Genmab, any former employer or any university he attended; views are his own. Developed with AI assistance, so errors or outdated details may exist. It reflects published guidance as of October 2026; check current sources. It is not medical, regulatory, reimbursement or legal advice, and it does not replace a systematic review where one is required (for example, HTA clinical evidence or EU JCA submissions). Provided as is, without warranty. You remain responsible for any review you run with it.
