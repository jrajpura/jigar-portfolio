# rwe-protocol-writer · version 1.0 (October 2026)

A skill that drafts observational real-world evidence (RWE) study protocols on the HARPER template, asks for missing inputs, and marks every gap [TO CONFIRM] instead of inventing it.

Built and explained step by step in Project 02 of jigarrajpura.com (Build a protocol-writing skill in ChatGPT). Skills follow the open Agent Skills format, so the same folder installs in ChatGPT and in Claude.

## Install in ChatGPT
1. Open Plugins, then the Skills tab.
2. Choose Create, then Upload from your computer, and upload this ZIP as downloaded.
3. Skills must be enabled for your workspace by its owner.

## Install in Claude
1. Open Customize › Skills.
2. Click +, then + Create skill, then Upload a skill, and upload this ZIP as downloaded.
3. Skills need code execution switched on.

## Test it
"Draft an RWE protocol for overall survival by PD-L1 status in HNSCC using US EHR data." It should ask for any missing inputs before drafting.

## What's inside
- SKILL.md: the workflow
- references/harper-template.md: HARPER section order with short notes
- references/variable-table-guide.md: the variable table format, with format-only examples
- Optional: add your own Word template as assets/protocol-shell.docx

## Disclaimer
Personal project by Jigar Rajpura. Not sponsored by or affiliated with Genmab, any former employer or any university he attended; views are his own. Developed with AI assistance, so errors or outdated details may exist. It reflects published guidance as of October 2026; check the current HARPER template and your organisation's SOPs. Drafts produced with it need scientific, statistical and compliance review. Provided as is, without warranty.
