# How to define a study variable

Every exposure, outcome, follow-up rule and covariate goes in a table with the same columns. The examples below show the level of detail expected. They are illustrations of format only: the clinical content is a placeholder, and every code list is left as [TO CONFIRM]. Never fill a code list from memory.

## Columns

| Column | What goes in it |
| --- | --- |
| Variable | Short name used in the analysis |
| Definition | Plain-language definition |
| Source field or code list | Data element, or the name of an appendix code list |
| Care setting | Inpatient, outpatient, emergency, pharmacy, any |
| Assessment window | Days relative to time 0, for example [-365, -1] |
| Algorithm source | Publication, prior study, or clinician review |
| Pre-specified? | Yes / no |
| Varied in sensitivity analysis? | Yes / no, and how |

## Worked examples (format only)

| Variable | Definition | Source field or code list | Care setting | Assessment window | Algorithm source | Pre-specified? | Varied in sensitivity? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Exposure: start of second-line therapy | First recorded administration of a second-line systemic regimen after first-line progression | Drug administration records; regimen list in Appendix A [TO CONFIRM] | Any | Day 0 (time 0) | Line-of-therapy algorithm, reference [TO CONFIRM] | Yes | Yes: alternative line-of-therapy rules |
| Outcome: overall survival | Time from time 0 to death from any cause | Linked mortality field [TO CONFIRM data source] | n/a | Day 0 to end of follow-up | Data provider documentation | Yes | Yes: restrict to sites with complete mortality linkage |
| Covariate: ECOG performance status | Most recent recorded ECOG score before time 0 | Structured ECOG field | Outpatient | [-90, 0] | Clinician review | Yes | Yes: window [-30, 0]; missing as own category vs multiple imputation |
| Follow-up end | Earliest of death, last recorded activity, data cut-off date | Activity and mortality fields | n/a | Day 0 onward | Protocol decision | Yes | Yes: censor at start of next line |

## Rules

- One row per variable; define the window relative to time 0, never by calendar date alone.
- State how missing values are handled for each covariate.
- Code lists live in appendices and are marked [TO CONFIRM] until a person has supplied or checked them.
