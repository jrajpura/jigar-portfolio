# HARPER section order

Section order for the protocol, following the HARmonized Protocol Template to Enhance Reproducibility (HARPER), a good practices report of a joint ISPE/ISPOR task force:
Wang SV, Pottegård A, Crown W, et al. Pharmacoepidemiol Drug Saf 2022 (doi:10.1002/pds.5507); also published in Value in Health 2022;25(10).
Download the official template and the worked examples from the publication before relying on this outline. The notes under each heading are my own summary of what the section should hold.

In the research-methods sections, HARPER pairs a short free-text "context and rationale" paragraph with a structured table of operational definitions. Keep that pattern.

1. **Title page.** Administrative table: title, brief objectives, version date, investigators, sponsor, registration, conflicts of interest.
2. **Abstract.** Background, research question and objectives, design, data sources.
3. **Amendments and updates.** Table of what changed, when, and why. The protocol is a living document.
4. **Timeline.** Table of milestones and dates.
5. **Rationale and background.** What is known about the condition and exposures, the knowledge gap, and what this study adds.
6. **Research question and objectives.** PICOT (population, intervention or exposure, comparator, outcome, time horizon) and the main effect measure; primary and secondary objectives, each with its hypothesis. Comparing the design with a hypothetical target trial helps here.
7. **Research methods**
   - 7.1 Study design: name the design and justify it.
   - 7.2 Study design diagram: a visual summary of time 0, washout, baseline, exposure and follow-up windows.
   - 7.3 Setting: rationale and operational definitions for time 0 (index date) and other time anchors; inclusion criteria; exclusion criteria.
   - 7.4 Variables: rationale and operational definitions for exposure(s), outcome(s) (including validation of outcome algorithms and which are primary), follow-up (how it starts and every way it ends), and covariates (how each is modelled).
   - 7.5 Data analysis: primary, secondary and subgroup analyses (models, confounding adjustment and its key parameters, missing-data handling); sensitivity analyses with the rationale for each.
   - 7.6 Data sources: why these data, strengths, limitations, provenance; a table of source, version, extraction date, linkage, common data model.
   - 7.7 Data management: receiving, checking, storing, backing up and preparing data.
   - 7.8 Quality control: for example double programming and checks on missing or miscoded data.
   - 7.9 Study size and feasibility: precision or power reasoning with stated assumptions and their sources.
8. **Limitations of the methods.** Anticipated limitations of the design and data.
9. **Protection of human subjects.** Privacy, de-identification, small-cell suppression, ethics review or exemption and why.
10. **Reporting of adverse events.** The plan, or "not applicable" with the reason.
11. **References.**
12. **Appendices.** Code lists and algorithms in machine-readable form, data linkage or common data model decisions. Code lists may be added in later protocol versions; record changes in section 3.

HARPER was built for hypothesis-evaluating studies of treatment effects; the authors note it can also serve descriptive, utilization or predictive studies, with some sections optional.
