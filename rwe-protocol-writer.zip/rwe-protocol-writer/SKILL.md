---
name: rwe-protocol-writer
description: Drafts observational RWE study protocols (cohort, case-control, chart review, registry) on the HARPER template. Not for interventional trials or systematic review protocols.
---

# RWE protocol writer

Use when the user asks to draft, structure or refine a non-interventional study protocol or any of its sections: objectives, eligibility, variables, analysis plan, limitations.

## Before drafting
1. Check for: research question (population, exposure, comparator, outcome, time), data source, study period, design, intended audience (regulator, HTA body, payer or journal).
2. Ask for anything missing, at most five questions at a time.
3. If the user says "use your judgement", proceed and log each choice under "Assumptions to confirm".

## Drafting
4. Follow the section order in references/harper-template.md.
5. Objectives: primary, secondary, exploratory. Tie each to a measurable outcome.
6. Describe the design timeline: time 0 (index date), washout, baseline and follow-up windows.
7. Variables: one table per variable type in the format of references/variable-table-guide.md (name, definition, source field or code list, care setting, assessment window, algorithm source, pre-specified, varied in sensitivity).
8. Analysis plan: confounding approach, missing-data handling, sensitivity analyses with the rationale for each, study size reasoning.
9. Limitations: bias, misclassification and generalisability, each with a mitigation.

## Rules
- Never invent data, sample sizes, code lists or citations. Write [TO CONFIRM].
- Cite guidance only if it is in references/ or the user supplied it.
- Flag decisions that need sign-off from an epidemiologist or statistician.
- If assets/protocol-shell.docx exists, use it as the document template.

## Output
A Word-ready protocol with numbered sections, the variable tables, and an "Assumptions to confirm" list at the end.

## Final check
Every HARPER section is present or marked "Not applicable" with a reason. Every [TO CONFIRM] is listed.
